Author : CodexWorld
Author URI : http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/codeigniter-file-upload-validation/

Installation Instructtion:
==================================================
1. Move all files to the same directory of your CodeIgniter application.
2. Move the "uploads/" directories to the project's root folder.
3. Open the URL (http://localhost/project_folder_name/files/upload) on the browser and check the file upload and validation functionality.

============ May I Help You ===========
If you have any query about this script, please feel free to comment here - http://www.codexworld.com/codeigniter-file-upload-validation/#respond. We will reply your query ASAP.