Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/add-remove-input-fields-group-dynamically-jquery/

============ Instruction ============
1. Open the index.html file on the browser ==> add more fields group.
2. Enter the values in the input groups and click the submit button. You will see all the value is retrieved in the PHP script.

============ May I Help You ===========
If you have any query about this script, send the query by post a comment here - http://www.codexworld.com/add-remove-input-fields-group-dynamically-jquery/#respond