Author : CodexWorld
Author URI : http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/ajax-pagination-in-codeigniter-framework/

Installation Instructtion:
==================================================
1. Import the posts.sql file into the database of your CodeIgniter application.
2. Move all files to the same directory of your CodeIgniter application.
3. Move the assets/ directory to the project's root folder.
4. Open the URL (http://localhost/project_folder_name/posts) on the browser and test the Ajax Pagination.

============ May I Help You ===========
If you have any query about this script, please feel free to comment here - http://www.codexworld.com/ajax-pagination-in-codeigniter-framework/#respond. We will reply your query ASAP.