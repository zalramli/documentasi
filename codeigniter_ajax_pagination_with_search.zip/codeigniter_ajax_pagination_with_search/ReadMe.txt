Author : CodexWorld
Author URI : http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/codeigniter-ajax-pagination-with-search-filter/

Installation Instructtion:
==================================================
1. Import the "db_posts.sql" file into the database and insert some demo data for testing purpose.
2. Move all files to the same directory of your CodeIgniter application.
2. Move the "assets/" directories to the project's root folder.
3. Open the URL (http://localhost/project_folder_name/posts) on the browser and check the ajax pagination with search and filter functionality.

============ May I Help You ===========
If you have any query about this script, please feel free to comment here - http://www.codexworld.com/codeigniter-ajax-pagination-with-search-filter/#respond. We will reply your query ASAP.